/*
 * tcpip_config.c
 *
 *  Created on: 20 sep 2022
 *      Author: Mauricio Amador
 */

#include <TCPIP/tcpip_config.h>

static struct netif netif;

	ip4_addr_t netif_ipaddr, netif_netmask, netif_gw;

	ethernetif_config_t enet_config = {
		.phyAddress = EXAMPLE_PHY_ADDRESS,
		.clockName  = EXAMPLE_CLOCK_NAME,
		.macAddress = configMAC_ADDR,
	};

/*Set parameters to config and set TCP*/
void ip_config(){

	SYSMPU_Type *base = SYSMPU;
	BOARD_InitPins();
	BOARD_BootClockRUN();
	BOARD_InitDebugConsole();

	/* Disable SYSMPU. */
	base->CESR &= ~SYSMPU_CESR_VLD_MASK;

	IP4_ADDR(&netif_ipaddr, configIP_ADDR0, configIP_ADDR1, configIP_ADDR2, configIP_ADDR3);
	IP4_ADDR(&netif_netmask, configNET_MASK0, configNET_MASK1, configNET_MASK2, configNET_MASK3);
	IP4_ADDR(&netif_gw, configGW_ADDR0, configGW_ADDR1, configGW_ADDR2, configGW_ADDR3);
}

/*Set parameters to config and set TCP*/
void tcp_config(){
	netifapi_netif_add(&netif, &netif_ipaddr, &netif_netmask, &netif_gw, &enet_config, EXAMPLE_NETIF_INIT_FN,
			tcpip_input);
	netifapi_netif_set_default(&netif);
	netifapi_netif_set_up(&netif);

	PRINTF("\r\n************************************************\r\n");
	PRINTF(" TCP Echo\r\n");
	PRINTF("************************************************\r\n");
	PRINTF(" IPv4 Address     : %u.%u.%u.%u\r\n", ((u8_t *)&netif_ipaddr)[0], ((u8_t *)&netif_ipaddr)[1],
		   ((u8_t *)&netif_ipaddr)[2], ((u8_t *)&netif_ipaddr)[3]);
	PRINTF(" IPv4 Subnet mask : %u.%u.%u.%u\r\n", ((u8_t *)&netif_netmask)[0], ((u8_t *)&netif_netmask)[1],
		   ((u8_t *)&netif_netmask)[2], ((u8_t *)&netif_netmask)[3]);
	PRINTF(" IPv4 Gateway     : %u.%u.%u.%u\r\n", ((u8_t *)&netif_gw)[0], ((u8_t *)&netif_gw)[1],
		   ((u8_t *)&netif_gw)[2], ((u8_t *)&netif_gw)[3]);
	PRINTF("************************************************\r\n");

}


