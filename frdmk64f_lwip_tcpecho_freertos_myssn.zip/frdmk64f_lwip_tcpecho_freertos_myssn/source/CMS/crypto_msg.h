/*
 * crypto_msg.h
 *
 *  Created on: 14 sep 2022
 *      Author: Mauricio
 */

#ifndef CMS_CRYPTO_MSG_H_
#define CMS_CRYPTO_MSG_H_

#define SHA256		256
#define SHA512		512

void AES_CRC_init();
void InitCrc32(CRC_Type *base, uint32_t seed);
void new_socket_crypto();

#endif /* CMS_CRYPTO_MSG_H_ */
