/*
 * crypto_msg.c
 *
 *  Created on: 14 sep 2022
 *      Author: Mauricio
 */

#include "crypto_msg_interface.h"

#include "lwip/opt.h"
#include "lwip/sys.h"
#include "lwip/api.h"

/*Global variables*/

struct netconn *conn, *newconn;

struct netbuf *buf;
void *data;

uint8_t key[] = KEYARRAY;
uint8_t iv[]  = IVARRAY;
struct AES_ctx ctx;
CRC_Type *base = CRC0;

err_t err;

static void *rcvddata_crypto(void *data, u16_t *len, struct netbuf *buf);
static void tcvddata_crypto(void *data, u16_t *len, struct netconn *newconn);
static void closeconn_crypto(struct netconn *newcon);

/*!
 * @brief Init for crypto function.
 * @details Init AES and CRC data.
 */
void AES_CRC_init(){

	/* Init the AES and CRC context structure */
	AES_init_ctx_iv(&ctx, key, iv);
	InitCrc32(base, SEED);
}

/*!
 * @brief Init for CRC-32.
 * @details Init CRC peripheral module for CRC-32 protocol.
 *          width=32 poly=0x04c11db7 init=0xffffffff refin=true refout=true xorout=0xffffffff check=0xcbf43926
 *          name="CRC-32"
 *          http://reveng.sourceforge.net/crc-catalogue/
 */
void InitCrc32(CRC_Type *base, uint32_t seed)
{
    crc_config_t config;

    config.polynomial         = 0x04C11DB7U;
    config.seed               = seed;
    config.reflectIn          = true;
    config.reflectOut         = true;
    config.complementChecksum = true;
    config.crcBits            = kCrcBits32;
    config.crcResult          = kCrcFinalChecksum;

    CRC_Init(base, &config);
}

void new_socket_crypto(){
	/* Create a new connection identifier. */
	/* Bind connection to well known port number 7. */
	/* LWIP_IPV6 */
	conn = netconn_new(NETCONN_TCP);
	PRINTF("Creating new connection \r\n");

	netconn_bind(conn, IP_ADDR_ANY, 7);
	/* LWIP_IPV6 */
	LWIP_ERROR("tcpecho: invalid conn", (conn != NULL), return;);

	/* Tell connection to go into listening mode. */
	netconn_listen(conn);
	PRINTF("Starting listing mode \r\n");
}

void aescrc_rcvr_task(void *data, u16_t *len){
	uint8_t padded_msg[SHA512] = {0};
	uint32_t checksum32;
	u32_t crc = 0;

	AES_CRC_init();

	char* rcvd;
	rcvd = (char*)data;
	/*Separate the CRC from the message, we need this data for validation
	* We change the order of the bytes, just like in the python scrip. Last byte go to the begin and so on*/
	crc = (*(rcvd+(*len-1)) << 24u) | (*(rcvd+(*len-2)) << 16u) | (*(rcvd+(*len-3)) << 8u) | (*(rcvd+(*len-4)));
	PRINTF("CRC rcvd: ");
	PRINTF("0x%02x \r\n", crc);

	/*Now that we know the CRC, we take out these four bytes from the length of the message*/
	*len = *len - 4;

	/*Copy data buffer to a new buffer limited to 512 bytes*/
	memcpy(padded_msg, data, *len);
	/*Calculate CRC from the message received in order to compare with the CRC received too*/
	CRC_WriteData(base, (uint8_t *)&padded_msg[0], *len);
	checksum32 = CRC_Get32bitResult(base);
	PRINTF("CRC calculated: ");
	PRINTF("0x%02x \r\n", checksum32);

	/*Make comparison*/
	if(crc == checksum32){
		PRINTF("CRC OK \r\n");
		/*If is true we can decrypt the message*/
		AES_CBC_decrypt_buffer(&ctx, padded_msg, *len);

		PRINTF("Decrypted Message: ");
		for(int i=0; i<*len; i++) {
			PRINTF("0x%02x,", padded_msg[i]);
		}
		PRINTF("\r\n");
	}
	else{
		PRINTF("CRC Error!\r\n");
	}

	/*Clean data and copy into it the decrypt message*/
	memset(data, 0, *len+4);
	memcpy(data, padded_msg, *len);

}

void aescrc_tcvr_task(void *data, u16_t *len){
	size_t padded_len;
	uint8_t padded_msg[SHA512] = {0};
	uint32_t checksum32;
	u16_t length;

	AES_CRC_init();

	/*Calculate the length from the data*/
	length = (u16_t)strlen((const char*)data);

	/*Copy data buffer to a new buffer limited to 512 bytes*/
	memcpy(padded_msg, data, length);

	/* To encrypt an array its length must be a multiple of 16 so we add zeros */
	padded_len = length + (16 - (length%16) );

	AES_CBC_encrypt_buffer(&ctx, padded_msg, padded_len);

	PRINTF("Encrypted Message: ");
	for(int i=0; i<padded_len; i++) {
		PRINTF("0x%02x,", padded_msg[i]);
	}
	PRINTF("\r\n");

	/*Create CRC for the message*/
	CRC_WriteData(base, (uint8_t *)&padded_msg[0], padded_len);
	checksum32 = CRC_Get32bitResult(base);
	PRINTF("CRC calculated: 0x%02x ", checksum32);

	/*Add CRC to the mwssage*/
	//memcpy(&padded_msg[padded_len], (char*)&checksum32, sizeof(checksum32));

	padded_msg[padded_len] = (checksum32 & 0xFF) >> 0;
	padded_msg[padded_len+1] = (checksum32 & 0xFF00) >> 8;
	padded_msg[padded_len+2] = (checksum32 & 0xFF0000) >> 16;
	padded_msg[padded_len+3] = (checksum32 & 0xFF000000) >> 24;

	/*Now that we add the CRC to the message, length has changed, we need to add 4 bytes and save it
	 * into a pointer to use this data outside this function*/
	*len = padded_len + sizeof(checksum32);

	/*Clean data and copy into it the encrypt message*/
	memset(data, 0, *len);
	memcpy(data, padded_msg, *len);

}

void processdata_crypto(){
	u16_t len = 0;

	/* Grab new connection. */
	err = netconn_accept(conn, &newconn);
	/*printf("accepted new connection %p\n", newconn);*/
	/* Process the new connection. */
	if (err == ERR_OK) {
		while ((err = netconn_recv(newconn, &buf)) == ERR_OK) {
			/*printf("Recved\n");*/
			do {

				data = rcvddata_crypto(data, &len, buf);

				tcvddata_crypto(data, &len, newconn);

			} while (netbuf_next(buf) >= 0);
		netbuf_delete(buf);
		}
		/*printf("Got EOF, looping\n");*/
		/* Close connection and discard connection identifier. */
		closeconn_crypto(newconn);
		}
}

static void *rcvddata_crypto(void *data, u16_t *len, struct netbuf *buf){
	/*Allocate buffer into data*/
	netbuf_data(buf, &data, len);

	/*Call the function that received the message and desencrypted*/
	aescrc_rcvr_task(data, len);

	return data;
}

static void tcvddata_crypto(void *data, u16_t *len, struct netconn *newconn){
	/*Call the function to encrypt the msg*/
	aescrc_tcvr_task(data, len);

	/*Send data through the TCP cpnnection to the client*/
	netconn_write(newconn, data, *len, NETCONN_COPY);
}

static void closeconn_crypto(struct netconn *newconn){
	netconn_close(newconn);
	netconn_delete(newconn);
}
