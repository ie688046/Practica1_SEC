/*
 * crypto_msg_interface.h
 *
 *  Created on: 23 sep 2022
 *      Author: Mauricio Amador
 */

#ifndef CMS_CRYPTO_MSG_INTERFACE_H_
#define CMS_CRYPTO_MSG_INTERFACE_H_

#include "netbuf.h"
#include <aes.h>
#include "fsl_crc.h"
#include "board.h"
#include "string.h"
#include "netif/ethernet.h"
#include "enet_ethernetif.h"
#include "crypto_msg_conf.h"
#include "crypto_msg.h"

void aescrc_rcvr_task(void *data, u16_t *len);
void aescrc_tcvr_task(void *data, u16_t *len);
void processdata_crypto();

#endif /* CMS_CRYPTO_MSG_INTERFACE_H_ */
